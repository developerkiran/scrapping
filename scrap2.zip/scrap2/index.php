<?php 

require 'vendor/autoload.php';
//require 'PHPExcel/Autoloader.php';


use Goutte\Client;

$client = new Client();

/*$objPHPExcel = new PHPExcel();
print_r($objPHPExcel);exit();
*/

$total_records = 696;
$per_page_data=24;

$pagination=$total_records/$per_page_data;

$results = [];

for ($i=0; $i <= $pagination ; $i++) { 

	$offset = ($pagination > $i) ? ($per_page_data * ($pagination - $i)) : 0;

	$link='https://www.homedepot.com/b/Bath-Bathroom-Accessories-Bathroom-Hardware/N-5yc1vZcfv8?Nao='.$offset;

	$page = $client->request('GET', $link);

	

	$results=$page->filter('.product-pod--padding')->each(function ($node) use ($results) {

		$results['brand_name']=$node->filter('.product-pod__title__brand--bold')->text();
		$results['description']=$node->filter('.product-pod__title__product')->text();
		$results['model_number']=$node->filter('.product-identifier__model')->text();
		$results['price']=$node->filter('.price-format__main-price span:nth-child(1)')->text().$node->filter('.price-format__main-price span:nth-child(2)')->text().'.'.$node->filter('.price-format__main-price span:nth-child(3)')->text();
		
		print_r($results);

		//return $results;


	});

}

exit();

print_r($results);


?>